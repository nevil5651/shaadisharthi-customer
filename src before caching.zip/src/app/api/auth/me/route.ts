// src/app/api/auth/me/route.ts
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

export async function GET() {
  const cookieStore = await cookies()
  const sessionCookie =  cookieStore.get('session')?.value

  if (!sessionCookie) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    // Extract the JWT token from your session cookie if needed
    // Or use the cookie directly if your backend accepts it
    
    // Call your actual backend API
    const backendResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/Customer/cstmr-acc`, {
      headers: {
        'Content-Type': 'application/json',
        'Cookie': `session=${sessionCookie}`
      },
      credentials: 'include' // Important for cookies
    })

    if (!backendResponse.ok) {
      throw new Error('Failed to fetch account details')
    }

    const userData = await backendResponse.json()
    return NextResponse.json(userData)
  } catch (error) {
    console.error('Account fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch account details' },
      { status: 500 }
    )
  }
}