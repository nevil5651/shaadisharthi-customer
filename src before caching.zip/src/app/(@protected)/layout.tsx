import { getSession } from '@/lib/session';
import "../globals.css";
import '@fortawesome/fontawesome-free/css/all.min.css';
import { AuthProvider } from '@/context/AuthContext';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { redirect } from 'next/navigation';
import { Geist, Geist_Mono } from 'next/font/google';
import { Metadata } from 'next';
import ToastProvider from '@/components/ToastProvider'

interface LayoutProps {
  children: React.ReactNode;
}
const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: 'ShaadiSharthi',
  description: 'Your one-stop platform for crafting unforgettable weddings with ease.',
}


export default async function ProtectedLayout({ children }: LayoutProps) {
  const session = await getSession();

  if (!session) {
    // This should theoretically not be hit if middleware is correct,
    // but it's a good failsafe.
    redirect('/login');
  }

//  const account = await getAccountDetails(session.customerId);

  return (
    <html lang="en">
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >          
    <AuthProvider>
      
      <div className="flex flex-col min-h-screen">
        
      <Header />
      <main className="flex-grow">
        <ToastProvider/>
        {children}</main>
      <Footer />
      </div>
    </AuthProvider>

     </body>
        </html>
  );
}