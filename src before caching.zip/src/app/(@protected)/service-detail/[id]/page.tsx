'use client';

import { useState, useEffect, useRef } from 'react';
import { notFound } from 'next/navigation';
import ServiceHero from '../components/ServiceHero';
import { PricingCard } from '../components/PricingCard';
import { ReviewsList } from '../components/ReviewsList';
import { ReviewForm } from '../components/ReviewForm';
import { MediaGallery } from '../components/MediaGallery';
import { fetchService, fetchReviews, ReviewsResponse, Service, Review } from '@/lib/service';
import React from 'react';

interface PageProps {
    params: Promise<{ id: string }>;
}

export default function ServiceDetailPage({ params }: PageProps) {
    const resolvedParams = React.use(params);
    const serviceId = resolvedParams.id;

    const [service, setService] = useState<Service | null>(null);
    const [reviews, setReviews] = useState<Review[]>([]);
    const [hasMore, setHasMore] = useState(true);
    const [page, setPage] = useState(1);
    const [serviceLoading, setServiceLoading] = useState(false);
    const [reviewsLoading, setReviewsLoading] = useState(false);
    const [serviceError, setServiceError] = useState<string | null>(null);
    const [reviewsError, setReviewsError] = useState<string | null>(null);
    const loaderRef = useRef<HTMLDivElement>(null);

    const loadService = async () => {
        if (!serviceId || serviceId === 'undefined') {
            setServiceError('Invalid service ID');
            return;
        }
        setServiceLoading(true);
        try {
            const serviceData = await fetchService(serviceId);
            if (!serviceData.serviceId) {
                throw new Error('Service ID missing in response');
            }
            console.log('Fetched service:', serviceData);
            setService(serviceData);
        } catch (err: unknown) {
            console.error('Error loading service:', err);
            if (err instanceof Error) {
                setServiceError(err.message);
            } else {
                setServiceError('Failed to load service');
            }
        } finally {
            setServiceLoading(false);
        }
    };

    const loadReviews = async (reset: boolean = false) => {
        if (!serviceId || serviceId === 'undefined') {
            setReviewsError('Invalid service ID');
            return;
        }
        setReviewsLoading(true);
        try {
            const reviewsData = await fetchReviews(serviceId, reset ? 1 : page);
            console.log(`Fetched reviews page ${reset ? 1 : page}:`, reviewsData.reviews);
            setReviews((prev) => reset ? reviewsData.reviews : [...prev, ...reviewsData.reviews]);
            setHasMore(reviewsData.hasMore);
            setPage((prev) => reset ? 2 : prev + 1);
        } catch (err: unknown) {
            console.error('Error loading reviews:', err);
            if (err instanceof Error) {
                setReviewsError(err.message);
            } else {
                setReviewsError('Failed to load reviews');
            }
        } finally {
            setReviewsLoading(false);
        }
    };

    useEffect(() => {
        setReviews([]);
        setPage(1);
        setHasMore(true);
        loadService();
        loadReviews(true);
    }, [serviceId]);

    useEffect(() => {
        if (reviewsLoading) return;
        const observer = new IntersectionObserver(
            (entries) => {
                if (entries[0].isIntersecting && hasMore && !reviewsLoading) {
                    loadReviews();
                }
            },
            { threshold: 1.0 }
        );
        if (loaderRef.current) observer.observe(loaderRef.current);
        return () => {
            if (loaderRef.current) observer.unobserve(loaderRef.current);
        };
    }, [hasMore, reviewsLoading, page, reviews.length]);

    const isTemp = (r: Review) => typeof r.reviewId === 'string' && r.reviewId.startsWith('temp-');


    const handleReviewSubmitted = (newReview: Review | null) => {
        // optimistic add or remove only
        if (newReview) {
            setReviews((prev) => [newReview, ...prev.filter(r => !isTemp(r))]);
        } else {
            setReviews((prev) => prev.filter(r => !isTemp(r)));
        }
        // don't refetch here; server will send authoritative list via onServerUpdate
    };

    const handleServerReviews = (serverList: Review[]) => {
        // server returned authoritative page-1; replace
        setReviews(serverList);
        // reset pagination so next fetch will load page 2
        setPage(2);
        setHasMore(true);
        // loadService(); 

        setService((prev) => prev ? {
        ...prev,
        reviewCount: prev.reviewCount + 1,
        rating: calcNewAverage(prev.rating, prev.reviewCount, serverList[0]?.rating ?? 0)
    } : prev);
    };



    if (serviceError) return <div className="container mx-auto px-4 py-8 text-red-600">{serviceError}</div>;
    if (!service || !service.serviceId || serviceLoading) {
        return <div className="container mx-auto px-4 py-8 text-gray-500">Loading service...</div>;
    }

    return (
        <main className="container bg-gray-50 font-['Poppins'] mx-auto px-4 py-8" >
            <ServiceHero service={service as any} reviews={reviews} />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
                <div className="lg:col-span-2 space-y-8">
                    <section className="bg-white rounded-xl shadow-md p-6">
                        <h2 className="text-2xl font-heading font-bold text-gray-900 mb-4">
                            About This Service
                        </h2>
                        <p className="text-gray-700">{service.description}</p>
                    </section>
                    {service.media && service.media.length > 0 && (
                        <MediaGallery media={service.media} />
                    )}
                    {reviewsError ? (
                        <div className="text-red-600 text-center py-4">{reviewsError}</div>
                    ) : (
                        <ReviewsList reviews={reviews} serviceId={service.serviceId} />
                    )}
                    {hasMore && (
                        <div ref={loaderRef} className="text-center py-4">
                            {reviewsLoading ? (
                                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary mx-auto"></div>
                            ) : (
                                <span className="text-gray-500">Scroll to load more reviews...</span>
                            )}
                        </div>
                    )}
                </div>
                <div className="lg:col-span-1 space-y-6">
                    <PricingCard service={service} />
                    <ReviewForm
       serviceId={service.serviceId}
       onSubmitSuccess={handleReviewSubmitted}
       onServerUpdate={handleServerReviews}
    />
                </div>
            </div>
        </main>
    );
}

function calcNewAverage(oldAvg: number, oldCount: number, newRating: number) {
    if (oldCount === 0) return newRating;
    return ((oldAvg * oldCount) + newRating) / (oldCount + 1);
}

