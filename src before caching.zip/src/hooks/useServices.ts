import { useState, useEffect, useRef, useCallback } from 'react';
import api from '@/lib/axios';
import { isAxiosError } from 'axios';
import debounce from 'lodash/debounce';
import { toast } from 'react-toastify';

// Define the structure of a service and the filters
export interface Service {
  id: string;
  serviceId: number;
  serviceName: string;
  businessName: string;
  imageUrl: string;
  price: number;
  rating: number;
  reviewCount: number;
  location: string;
  category: string;
}

export interface ServiceFilters {
  category: string;
  location: string;
  minPrice: string;
  maxPrice: string;
  rating: string;
  sortBy: string;
}

export const useServices = (initialFilters: ServiceFilters) => {
  const [filters, setFilters] = useState(initialFilters);
  const [services, setServices] = useState<Service[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const loaderRef = useRef<HTMLDivElement>(null);
  const isFetchingRef = useRef(false);
  const latestPageRef = useRef(1);

  const fetchServices = useCallback(
    async (isNewSearch = false) => {
      if (isFetchingRef.current || (!isNewSearch && !hasMore)) {
        console.log('Fetch blocked:', { isFetching: isFetchingRef.current, isNewSearch, hasMore, page });
        return;
      }
      isFetchingRef.current = true;
      setIsLoading(true);
      setError('');
      let currentPage = isNewSearch ? 1 : page;

      // Increment page before fetch for non-new searches
      if (!isNewSearch && hasMore) {
        currentPage = page + 1;
        setPage(currentPage);
        latestPageRef.current = currentPage;
        console.log('Incrementing page to:', currentPage);
      }

      console.log('Fetching services:', { isNewSearch, page: currentPage, filters });

      const query = new URLSearchParams({
        page: String(currentPage),
        limit: '12',
        ...(filters.category && { category: filters.category }),
        ...(filters.location && { location: filters.location }),
        ...(filters.minPrice && { minPrice: filters.minPrice }),
        ...(filters.maxPrice && { maxPrice: filters.maxPrice }),
        ...(filters.rating && { rating: filters.rating }),
        ...(filters.sortBy && { sortBy: filters.sortBy }),
      }).toString();

      try {
        const response = await api.get(`/Customer/services?${query}`);
        const { services: backendServices, hasMore: more } = response.data;

        if (currentPage === latestPageRef.current) {
          const formattedServices = backendServices.map((service: any, index: number) => ({
            ...service,
            id: `${service.serviceId}-${currentPage}-${index}`,
            imageUrl: service.imageUrl || '/img/default-vendor.jpg',
          }));

          setServices((prev) => {
            const newServices = isNewSearch ? formattedServices : [...prev, ...formattedServices];
            console.log('Updating services:', { newCount: newServices.length, isNewSearch });
            return newServices;
          });
          setHasMore(more);
          console.log('Fetch successful:', { services: formattedServices.length, hasMore: more, nextPage: currentPage + 1 });
        } else {
          console.log('Discarding outdated fetch:', { fetchedPage: currentPage, latestPage: latestPageRef.current });
        }
      } catch (err) {
        if (isAxiosError(err)) {
          if (err.response?.status === 401) return; // Handled by interceptor
          const message = err.response?.status === 429 ? 'Too many requests.' : 'Failed to load services.';
          setError(message);
          toast.error(message);
        } else {
          const message = 'An unexpected error occurred.';
          setError(message);
          toast.error(message);
        }
        console.error('Fetch error:', err);
      } finally {
        isFetchingRef.current = false;
        setIsLoading(false);
      }
    },
    [filters, page, hasMore]
  );

  // Debounced filter updates with equality check
  const debouncedSetFilters = useCallback(
    debounce((newFilters: ServiceFilters) => {
      if (
        newFilters.category === filters.category &&
        newFilters.location === filters.location &&
        newFilters.minPrice === filters.minPrice &&
        newFilters.maxPrice === filters.maxPrice &&
        newFilters.rating === filters.rating &&
        newFilters.sortBy === filters.sortBy
      ) {
        console.log('Filters unchanged, skipping update');
        return;
      }
      setFilters(newFilters);
      setPage(1);
      setHasMore(true);
      setServices([]);
      latestPageRef.current = 1;
      console.log('Filters updated:', newFilters);
    }, 300),
    [filters]
  );

  // Effect for initial fetch and filter changes
  useEffect(() => {
    fetchServices(true);
  }, [filters]);

  // Debounced observer callback
  const debouncedFetch = useCallback(
    debounce(() => {
      console.log('Debounced fetch triggered, page:', page);
      fetchServices();
    }, 300),
    [fetchServices]
  );

  // Effect for infinite scroll
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const isVisible = entries[0].isIntersecting;
        console.log('IntersectionObserver check:', { isVisible, hasMore, isFetching: isFetchingRef.current, error, page });
        if (isVisible && hasMore && !isFetchingRef.current && !error) {
          debouncedFetch();
        }
      },
      {
        threshold: 0.5,
        rootMargin: '200px',
      }
    );

    const currentLoader = loaderRef.current;
    if (currentLoader) {
      console.log('Observing loader element:', currentLoader);
      observer.observe(currentLoader);
    } else {
      console.warn('Loader element not found');
    }

    return () => {
      if (currentLoader) {
        console.log('Cleaning up observer');
        observer.unobserve(currentLoader);
      }
      debouncedFetch.cancel();
    };
  }, [debouncedFetch]);

  return { services, filters, setFilters: debouncedSetFilters, isLoading, error, hasMore, loaderRef };
};