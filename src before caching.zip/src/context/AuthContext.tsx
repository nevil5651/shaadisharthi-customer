'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

interface User {
  id: string
  name: string
  email: string
  phone_no: string
  address?: string
  created_at: string
  avatar?: string
}

interface Credentials {
  [key: string]: string;
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (credentials: Credentials) => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
  updateUser: (updatedData: Partial<User>) => Promise<void>
  fetchProfile: () => Promise<void>
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // src/context/AuthContext.tsx
const fetchProfile = async () => {
    try {
      const res = await fetch('/api/auth/me', {
        credentials: 'include' 
      });
      
      // Don't redirect if we're on register page with token
      const isRegisterWithToken = window.location.pathname === '/register' && 
                                 new URLSearchParams(window.location.search).has('token');
      
      if (res.status === 401 && !isRegisterWithToken) {
        await logout();
        router.push('/login');
        return;
      }

      if (!res.ok) throw new Error('Failed to fetch profile');

      const userData = await res.json();
      setUser(userData);
    } catch (error) {
      console.error('Failed to fetch profile:', error);
      // Don't throw error for register page with token
      const isRegisterWithToken = window.location.pathname === '/register' && 
                                 new URLSearchParams(window.location.search).has('token');
      if (!isRegisterWithToken) {
        throw error;
      }
    }
  };

  useEffect(() => {
    // Initial load - check if user is logged in
    fetchProfile().finally(() => setIsLoading(false))
  }, [])

  const login = async (credentials: Credentials) => {
    setIsLoading(true)
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL
      if (!apiUrl) {
        throw new Error("API URL is not configured")
      }

      // 1. Authenticate with backend
      const backendRes = await fetch(`${apiUrl}/Customer/signin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials),
      })

      if (!backendRes.ok) {
        const errorData = await backendRes.json()
        return { success: false, error: errorData.message || 'Authentication failed' }
      }

      const { token } = await backendRes.json()

      // 2. Create session with Next.js API
      const sessionRes = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      })

      if (!sessionRes.ok) {
        return { success: false, error: 'Failed to create session' }
      }

      // 3. Redirect immediately without waiting for profile
      router.push('/dashboard')

      // 4. Kick off profile fetch in background
      fetchProfile().catch(error => {
        console.error('Background profile fetch failed:', error)
      })

      return { success: true }
    } catch (error) {
      console.error('Login error:', error)
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Login failed' 
      }
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      setUser(null)
      router.push('/login')
    } catch (error) {
      console.error('Logout error:', error)
    }
  }

  // In your AuthContext
const updateUser = async (updatedData: Partial<User>) => {
  setUser(prev => {
    if (!prev) return null;
    return {
      ...prev,
      ...updatedData,
      // Ensure critical fields are never null
      name: updatedData.name || prev.name,
      email: prev.email // Always keep original email
    };
  });
};

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    updateUser,
    fetchProfile,
  }


  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}