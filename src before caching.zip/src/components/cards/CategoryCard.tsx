import React, { memo } from 'react';

interface CategoryCardProps {
  category: string;
  icon: string;
  colorClass: { bg: string; text: string };
  isSelected: boolean;
  onClick: (category: string) => void;
}

const CategoryCard: React.FC<CategoryCardProps> = ({
  category,
  icon,
  colorClass,
  isSelected,
  onClick,
}) => {
  const iconClasses = `fas ${icon} text-lg`;
  const bgClass = isSelected
    ? 'bg-white text-primary shadow-md'
    : `${colorClass.bg} text-${colorClass.text}`;

  return (
    <button
      onClick={() => onClick(category)}
      className={`flex items-center p-3 bg-white rounded-lg hover:shadow-md transition-all ${
        isSelected ? 'shadow-md' : ''
      }`}
    >
      <div className={`category-icon w-10 h-10 rounded-full flex items-center justify-center mr-3 ${bgClass}`}>
        <i className={iconClasses}></i>
      </div>
      <span className="font-medium">{category}</span>
    </button>
  );
};

export default memo(CategoryCard, (prevProps, nextProps) => {
  return prevProps.category === nextProps.category &&
         prevProps.icon === nextProps.icon &&
         prevProps.colorClass.bg === nextProps.colorClass.bg &&
         prevProps.colorClass.text === nextProps.colorClass.text &&
         prevProps.isSelected === nextProps.isSelected;
});