import Image from 'next/image';
import { Media } from '@/lib/service';

interface MediaGalleryProps {
  media: Media[];
}

export function MediaGallery({ media }: MediaGalleryProps) {
  return (
    <section className="bg-white rounded-xl shadow-md p-6 mb-8">
      <h2 className="text-2xl font-heading font-bold text-gray-900 mb-4">Media Gallery</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {media.map((item) => (
          <div key={item.url} className="relative aspect-video rounded-lg overflow-hidden">
            {item.type === 'Image' ? (
              <Image
                src={item.url}
                alt={`${item.type} from ${item.url}`}
                width={400}
                height={300}
                className="object-cover w-full h-full"
              />
            ) : item.type === 'Video' ? (
              <video controls className="w-full h-full">
                <source src={item.url} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  );
}