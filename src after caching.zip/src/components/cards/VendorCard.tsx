import React, { memo } from 'react';
import Link from 'next/link';
import { RatingStars } from '@/components/ui/RatingStars';
import Button from '../ui/Button';

interface Vendor {
  id: string; // Changed to string to match useServices.ts
  serviceId: number;
  serviceName: string;
  businessName: string;
  imageUrl: string;
  price: number;
  rating: number;
  reviewCount: number;
  location: string;
  category: string;
}

interface VendorCardProps {
  vendor: Vendor;
}

const VendorCard: React.FC<VendorCardProps> = ({ vendor }) => {
  const getCategoryInfo = (category: string) => {
    const categoryMap = {
      Photography: { color: 'bg-indigo-600', icon: 'fa-camera' },
      Venues: { color: 'bg-purple-600', icon: 'fa-building' },
      Sound: { color: 'bg-purple-600', icon: 'fa-volume-up' },
      Catering: { color: 'bg-green-600', icon: 'fa-utensils' },
      Decoration: { color: 'bg-pink-600', icon: 'fa-paint-brush' },
      'Bridal Wear': { color: 'bg-red-600', icon: 'fa-tshirt' },
      Jewellery: { color: 'bg-yellow-600', icon: 'fa-gem' },
      Favors: { color: 'bg-blue-600', icon: 'fa-gift' },
      Planners: { color: 'bg-teal-600', icon: 'fa-clipboard-list' },
      'Bridal Makeup': { color: 'bg-pink-600', icon: 'fa-magic' },
      Videographers: { color: 'bg-indigo-600', icon: 'fa-video' },
      'Groom Wear': { color: 'bg-blue-600', icon: 'fa-user-tie' },
      'Mehendi Artists': { color: 'bg-orange-600', icon: 'fa-paint-brush' },
      Cakes: { color: 'bg-pink-600', icon: 'fa-birthday-cake' },
      Cards: { color: 'bg-red-600', icon: 'fa-envelope' },
      Choreographers: { color: 'bg-purple-600', icon: 'fa-music' },
      Entertainment: { color: 'bg-yellow-600', icon: 'fa-star' },
      Beauty: { color: 'bg-pink-600', icon: 'fa-magic' },
      default: { color: 'bg-gray-600', icon: 'fa-star' },
    };
    return categoryMap[category as keyof typeof categoryMap] || categoryMap['default'];
  };

  const formatPrice = (price: number) => {
    if (price >= 10000000) {
      const crores = (price / 10000000).toFixed(1);
      return `${crores} Cr`;
    }
    if (price >= 100000) {
      const lakhs = (price / 100000).toFixed(1);
      return `${lakhs} L`;
    }
    return new Intl.NumberFormat('en-IN').format(price);
  };

  const fullPrice = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
  }).format(vendor.price);

  const categoryInfo = getCategoryInfo(vendor.category);

  // Normalize image URL
  const imageUrl = vendor.imageUrl === '/img/default-service.jpg' 
    ? '/img/default-vendor.jpg' 
    : vendor.imageUrl || '/img/default-vendor.jpg';

  return (
    <div className="vendor-card bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-all duration-300 hover:-translate-y-1 flex flex-col h-full">
      <div className="relative h-48 overflow-hidden">
        <img
          src={imageUrl}
          alt={vendor.serviceName}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
          loading="lazy"
          // onError={(e) => {
          //   e.currentTarget.src = '/img/default-vendor.jpg';
          // }}
        />
        <span className={`category-tag absolute top-3 right-3 text-white text-xs px-2 py-1 rounded-full ${categoryInfo.color} flex items-center`}>
          <i className={`fas ${categoryInfo.icon} mr-1 text-xs`}></i>
          <span className="truncate max-w-[100px]">{vendor.category}</span>
        </span>
      </div>

      <div className="p-5 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-gray-800 mb-1 line-clamp-1 relative group" title={vendor.serviceName}>
          {vendor.serviceName}
          <span className="absolute hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 -top-8 left-1/2 transform -translate-x-1/2 z-10">
            {vendor.serviceName}
          </span>
        </h3>

        <div className="flex items-center text-gray-500 text-sm mb-2 relative group">
          <i className="fas fa-map-marker-alt mr-1 text-xs"></i>
          <span className="truncate" title={vendor.location}>{vendor.location}</span>
          <span className="absolute hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 -top-8 left-1/2 transform -translate-x-1/2 z-10">
            {vendor.location}
          </span>
        </div>

        <div className="flex items-center mb-3">
          <RatingStars rating={vendor.rating} />
          <span className="text-xs text-gray-500 ml-1">({vendor.reviewCount})</span>
        </div>

        <div className="mt-auto pt-3 border-t border-gray-100 flex justify-between items-end">
          <div className="flex flex-col min-w-0">
            <span className="text-xl font-bold text-primary truncate" title={fullPrice}>
              ₹{formatPrice(vendor.price)}
            </span>
            <span className="text-xs text-gray-500 whitespace-nowrap">starting price</span>
          </div>

          <Link
            href={`/service-detail/${vendor.serviceId}`}
            className="text-primary hover:text-opacity-80 font-medium text-sm whitespace-nowrap px-3 py-2 rounded-md hover:bg-primary hover:bg-opacity-10 transition-colors flex items-center shrink-0"
          >
            View <i className="fas fa-arrow-right ml-1.5 text-xs"></i>
          </Link>

        </div>
      </div>
    </div>
  );
};

export default memo(VendorCard, (prevProps, nextProps) => {
  return prevProps.vendor.id === nextProps.vendor.id &&
         prevProps.vendor.serviceName === nextProps.vendor.serviceName &&
         prevProps.vendor.businessName === nextProps.vendor.businessName &&
         prevProps.vendor.category === nextProps.vendor.category &&
         prevProps.vendor.location === nextProps.vendor.location &&
         prevProps.vendor.rating === nextProps.vendor.rating &&
         prevProps.vendor.reviewCount === nextProps.vendor.reviewCount &&
         prevProps.vendor.price === nextProps.vendor.price &&
         prevProps.vendor.imageUrl === nextProps.vendor.imageUrl;
});