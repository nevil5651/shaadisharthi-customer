'use client'
import { useState, useEffect, useCallback, useMemo } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import axios from 'axios';
import { toast } from 'react-toastify';
import AuthCard from '@/components/cards/AuthCard';
import { FaUser, FaEnvelope, FaPhone, FaPhoneAlt, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa';
import dynamic from 'next/dynamic';

// Dynamically import SocialLogin to reduce initial bundle size
const SocialLogin = dynamic(() => import('@/components/ui/SocialLogin'), {
  ssr: false,
  loading: () => <div className="h-16 flex items-center justify-center text-gray-600 dark:text-gray-400">Loading social login options...</div>
});

// Updated validation schema with token (optional for now)
export const registerSchema = z.object({
  name: z.string().min(1, { message: 'Full name is required.' }),
  email: z.string().min(1, { message: 'Email is required.' }).email({ message: 'Invalid email address.' }),
  phone: z.string().length(10, { message: 'Phone number must be 10 digits.' }).regex(/^\d+$/, { message: 'Invalid phone number.' }),
  altPhone: z.string().length(10, { message: 'Alternate phone must be 10 digits.' }).regex(/^\d+$/, { message: 'Invalid phone number.' }).optional().or(z.literal('')),
  password: z.string().min(6, { message: 'Password must be at least 6 characters.' }),
  confirmPassword: z.string().min(6, { message: 'Please confirm your password.' }),
  termsAccepted: z.boolean().refine(val => val === true, { message: 'You must accept the Terms & Conditions.' }),
  token: z.string().min(1, { message: 'Verification token is required.' }).optional(), // Make required in Zod if strictly enforcing
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

export type RegisterFormInputs = z.infer<typeof registerSchema>;

interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ElementType;
  type: string;
  placeholder?: string;
  disabled?: boolean;
  error?: string;
  showPasswordToggle?: boolean;
  isPasswordVisible?: boolean;
  onTogglePassword?: () => void;
}

// Memoized form inputs to prevent unnecessary re-renders
const FormInput: React.FC<FormInputProps> = ({
  icon,
  type,
  placeholder,
  disabled,
  error,
  showPasswordToggle,
  isPasswordVisible,
  onTogglePassword,
  ...registerProps
}) => {
  const InputIcon = useMemo(() => icon, [icon]);
  
  return (
    <div>
      <div className="relative">
        <div className="input-icon">{InputIcon && <InputIcon />}</div>
        <input 
          type={type} 
          placeholder={placeholder} 
          className={`form-input w-full pl-10 pr-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400 ${disabled ? 'bg-gray-100 dark:bg-gray-600 cursor-not-allowed' : ''}`} 
          disabled={disabled} 
          {...registerProps} 
        />
        {showPasswordToggle && (
          <button 
            type="button" 
            className="password-toggle absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300" 
            onClick={onTogglePassword}
            disabled={disabled}
          >
            {isPasswordVisible ? <FaEyeSlash /> : <FaEye />}
          </button>
        )}
      </div>
      {error && <p className="text-red-500 dark:text-red-400 text-sm mt-1">{error}</p>}
    </div>
  );
};

export default function Register() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const [isVerified, setIsVerified] = useState(false);

  const { register, handleSubmit, formState: { errors, isSubmitting }, setValue } = useForm<RegisterFormInputs>({
    resolver: zodResolver(registerSchema),
    mode: 'onChange' // Validate on change for better UX
  });

  // Memoize the token verification function
  const verifyToken = useCallback(async () => {
    if (!token) {
      router.push('/verify-email');
      return;
    }

    setIsLoading(true);
    setApiError(null);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL;
      const response = await axios.get(`${apiUrl}/Customer/cstmr-email-verification?token=${token}`);
      if (response.data.email) {
        setValue('email', response.data.email);
        setValue('token', token);
        setIsVerified(true);
      } else {
        throw new Error('Invalid response');
      }
    } catch (err) {
      setApiError('Invalid or expired verification token. Redirecting...');
      setTimeout(() => router.push('/verify-email'), 3000);
    } finally {
      setIsLoading(false);
    }
  }, [token, router, setValue]);

  useEffect(() => {
    verifyToken();
  }, [verifyToken]);

  const onSubmit = useCallback(async (data: RegisterFormInputs) => {
    setIsLoading(true);
    setApiError(null);
    const toastId = toast.loading("Creating your account...");

    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL;
      if (!apiUrl) {
        throw new Error("API URL is not configured.");
      }

      const { confirmPassword, termsAccepted, ...payload } = data;

      await axios.post(`${apiUrl}/Customer/cstmr-rgt`, payload);

      toast.update(toastId, {
        render: 'Registration successful! Redirecting to login...',
        type: 'success',
        isLoading: false,
        autoClose: 2000,
      });

      // Redirect after a short delay to allow the user to see the toast.
      setTimeout(() => {
        router.push('/login');
      }, 2000);

    } catch (err) {
      console.error('Registration failed:', err);
      let errorMessage = 'An unexpected error occurred.';
      if (axios.isAxiosError(err) && err.response) {
        errorMessage = err.response.data.error || 'Registration failed. Please try again.';
      } else if (err instanceof Error) {
        errorMessage = err.message;
      }
      setApiError(errorMessage);
      toast.update(toastId, { render: errorMessage, type: 'error', isLoading: false, autoClose: 5000 });
      // Only re-enable the form on failure
      setIsLoading(false);
    }
  }, [router]);

  const togglePassword = useCallback(() => {
    setShowPassword(prev => !prev);
  }, []);

  const toggleConfirmPassword = useCallback(() => {
    setShowConfirmPassword(prev => !prev);
  }, []);

  if (!isVerified && token) {
    return (
      <div className="auth-page min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 py-8 px-4">
        <AuthCard title="Verifying..." subtitle="Please wait while we verify your email">
          {apiError && <p className="text-red-500 dark:text-red-400 text-center">{apiError}</p>}
        </AuthCard>
      </div>
    );
  }

  return (
    <div className="auth-page min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 py-8 px-4">
      <AuthCard title="Create Your Account" subtitle="Join us to begin your journey">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {apiError && (
            <div className="p-3 mb-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-900 dark:bg-opacity-20 dark:text-red-300" role="alert">
              {apiError}
            </div>
          )}

          {/* Hidden Token Field */}
          <input type="hidden" {...register('token')} />

          {/* Name Field */}
          <FormInput
            icon={FaUser}
            type="text"
            placeholder="Full Name"
            disabled={isLoading}
            error={errors.name?.message}
            {...register('name')}
          />

          {/* Email Field (prefilled and disabled if verified) */}
          <FormInput
            icon={FaEnvelope}
            type="email"
            placeholder="Email Address"
            disabled={isVerified || isLoading}
            error={errors.email?.message}
            {...register('email')}
          />

          {/* Phone Field */}
          <FormInput
            icon={FaPhone}
            type="tel"
            placeholder="Phone Number"
            disabled={isLoading}
            error={errors.phone?.message}
            {...register('phone')}
          />

          {/* Alternate Phone Field */}
          <FormInput
            icon={FaPhoneAlt}
            type="tel"
            placeholder="Alternate Phone Number (Optional)"
            disabled={isLoading}
            error={errors.altPhone?.message}
            {...register('altPhone')}
          />

          {/* Password Field */}
          <FormInput
            icon={FaLock}
            type={showPassword ? "text" : "password"}
            placeholder="Password"
            disabled={isLoading}
            error={errors.password?.message}
            showPasswordToggle={true}
            isPasswordVisible={showPassword}
            onTogglePassword={togglePassword}
            {...register('password')}
          />

          {/* Confirm Password Field */}
          <FormInput
            icon={FaLock}
            type={showConfirmPassword ? "text" : "password"}
            placeholder="Confirm Password"
            disabled={isLoading}
            error={errors.confirmPassword?.message}
            showPasswordToggle={true}
            isPasswordVisible={showConfirmPassword}
            onTogglePassword={toggleConfirmPassword}
            {...register('confirmPassword')}
          />

          {/* Terms and Conditions */}
          <div className="flex items-start mb-6">
            <div className="flex items-center h-5">
              <input
                id="terms"
                type="checkbox"
                {...register('termsAccepted')}
                className="w-4 h-4 text-pink-600 border-gray-300 rounded focus:ring-pink-500 dark:bg-gray-700 dark:border-gray-600"
                disabled={isLoading}
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="terms" className="text-gray-700 dark:text-gray-300">
                I agree to the{' '}
                <Link href="/terms" className="text-pink-600 dark:text-pink-400 hover:underline">
                  Terms & Conditions
                </Link>{' '}
                and{' '}
                <Link href="/privacy" className="text-pink-600 dark:text-pink-400 hover:underline">
                  Privacy Policy
                </Link>
              </label>
            </div>
          </div>
          {errors.termsAccepted && <p className="text-red-500 dark:text-red-400 text-sm -mt-4 mb-4">{errors.termsAccepted.message}</p>}

          {/* Submit Button */}
          <button type="submit" className="gradient-btn w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 transition duration-150 ease-in-out disabled:opacity-50 dark:focus:ring-offset-gray-800" disabled={isLoading || isSubmitting}>
            {isLoading ? (
              <div className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Registering...
              </div>
            ) : 'Register Now'}
          </button>

          <SocialLogin />
          
          <div className="text-center text-gray-700 dark:text-gray-300">
            <p>
              Already have an account?{' '}
              <Link href="/login" className="text-pink-600 dark:text-pink-400 font-medium hover:underline">
                Sign In
              </Link>
            </p>
          </div>
        </form>
      </AuthCard>
    </div>
  );
};