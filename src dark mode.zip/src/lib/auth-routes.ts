
export const publicRoutes = ['/login', '/signup','/verify-email', '/register', '/cstmr-verify-email', '/forgot-password', '/reset-password'];
